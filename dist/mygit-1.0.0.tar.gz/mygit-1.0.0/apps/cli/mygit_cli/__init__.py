"""
MyGit CLI Application
"""
