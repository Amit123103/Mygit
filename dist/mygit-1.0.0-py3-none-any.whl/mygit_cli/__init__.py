"""
MyGit CLI Application
"""
